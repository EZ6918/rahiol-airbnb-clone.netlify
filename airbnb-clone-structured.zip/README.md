# Airbnb Clone (Structured)

This project clones a simplified Airbnb front-end using **React + Vite** with the required structure.

### Run locally
```bash
npm install
npm run dev
```
