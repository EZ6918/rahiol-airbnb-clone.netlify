const img = (n) => `/src/assets/images/placeholder_${((n - 1) % 5) + 1}.svg`

function mkItems(prefix) {
  return Array.from({ length: 7 }).map((_, i) => ({
    id: `${prefix}-${i+1}`,
    image: img(i+1),
    title: `${prefix} Stay ${i+1}`,
    location: ['Manila','Cebu','Baguio','Siargao','Palawan','Davao','La Union'][i],
    price: 1500 + i * 350,
    rating: (4 + (i % 2 ? 0.6 : 0.2)).toFixed(1)
  }))
}

export const categories = [
  { title: 'Beachfront', items: mkItems('Beach') },
  { title: 'City Apartments', items: mkItems('City') },
  { title: 'Countryside', items: mkItems('Country') },
  { title: 'Unique Stays', items: mkItems('Unique') },
]
