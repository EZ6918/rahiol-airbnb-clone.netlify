import ListingCard from './ListingCard'

export default function CategoryCard({ title, items }) {
  return (
    <section>
      <h2>{title}</h2>
      <div className="grid">
        {items.map((it) => (
          <ListingCard key={it.id} {...it} />
        ))}
      </div>
    </section>
  )
}
