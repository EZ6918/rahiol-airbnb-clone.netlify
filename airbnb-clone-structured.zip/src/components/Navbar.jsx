import { NavLink, useNavigate } from 'react-router-dom'
import SearchBar from './SearchBar'

export default function Navbar({ search, setSearch }) {
  const navigate = useNavigate()
  function handleSubmit(e) {
    e.preventDefault()
    navigate('/listing')
  }

  return (
    <header className="navbar">
      <div className="brand">airbnb•clone</div>
      <SearchBar search={search} setSearch={setSearch} onSubmit={handleSubmit} />
      <nav>
        <NavLink to="/" end>Home</NavLink>
        <NavLink to="/listing">Listing</NavLink>
      </nav>
    </header>
  )
}
