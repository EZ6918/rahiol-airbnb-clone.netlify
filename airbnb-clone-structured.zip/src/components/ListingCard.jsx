export default function ListingCard({ image, title, location, price, rating }) {
  return (
    <article className="card">
      <img src={image} alt={title} />
      <div className="card-body">
        <h3>{title}</h3>
        <p>{location} • ⭐ {rating} • ₱{price.toLocaleString()}</p>
      </div>
    </article>
  )
}
