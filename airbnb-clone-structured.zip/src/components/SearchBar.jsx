export default function SearchBar({ search, setSearch, onSubmit }) {
  return (
    <form className="searchbar" onSubmit={onSubmit}>
      <input
        type="text"
        placeholder="Search destinations…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
      <button type="submit">Search</button>
    </form>
  )
}
