export default function Icon({ name, size = 24 }) {
  return <img src={`/src/assets/icons/${name}.svg`} alt={name} width={size} height={size} />
}
