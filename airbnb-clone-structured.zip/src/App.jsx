import { Routes, Route } from 'react-router-dom'
import { useState } from 'react'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Home from './pages/Home'
import Listing from './pages/Listing'

export default function App() {
  const [search, setSearch] = useState('')

  return (
    <div>
      <Navbar search={search} setSearch={setSearch} />
      <Routes>
        <Route path="/" element={<Home search={search} />} />
        <Route path="/listing" element={<Listing search={search} />} />
      </Routes>
      <Footer />
    </div>
  )
}
