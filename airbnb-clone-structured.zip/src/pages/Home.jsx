import CategoryCard from '../components/CategoryCard'
import { categories } from '../data/sampleData'

export default function Home({ search }) {
  const filtered = categories.map(cat => ({
    ...cat,
    items: cat.items.filter(i => i.title.toLowerCase().includes(search.toLowerCase()) || i.location.toLowerCase().includes(search.toLowerCase()))
  }))

  return (
    <main>
      {filtered.map((c) => (
        <CategoryCard key={c.title} title={c.title} items={c.items} />
      ))}
    </main>
  )
}
